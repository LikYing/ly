package com.example.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

import com.example.myclass.R;

public class VideoPlayActivity extends AppCompatActivity {

    private VideoView videoView;
    private MediaController controller;
    private String videoPath;    // 视频地址
    private int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //设置界面全屏显示
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_video_play);
        //设置界面为横屏
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        //获取从视频详情界面或播放记录界面传递过来的视频地址
        videoPath = getIntent().getStringExtra("videoPath");
        position = getIntent().getIntExtra("position",0);
        init();
    }
    private void init() {
        videoView = (VideoView) findViewById(R.id.videoView);
        controller = new MediaController(this);
        videoView.setMediaController(controller);
        play();
    }
    /**
     * 实现播放视频功能
     */
    private void play() {
        if (TextUtils.isEmpty(videoPath)) {
            Toast.makeText(this, "没有此视频，暂无法播放", Toast.LENGTH_SHORT).show();
            return;
        }
        String uri = "android.resource://" + getPackageName() + "/" + R.raw.video11;
        videoView.setVideoPath(videoPath); 	//加载视频地址
        videoView.start(); 					//播放视频
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        //把视频详情页面的视频地址传递回去
        Intent data = new Intent();
        data.putExtra("position",position);
        setResult(RESULT_OK,data);
        return super.onKeyDown(keyCode, event);
    }
}
