package com.example.bean;

public class UserBean {
    public String userName;//用户名
    public String nickName;//昵称
    public String sex;//性别
    public String signature;//签名
}
