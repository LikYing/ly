package com.example.bean;


public class CourseBean{
    public int id;                 		// 章节id
    public String imgTitle;  		// 图片上的标题
    public String title; 		// 章节标题
    public String intro;   		// 章节视频简介
    public String icon;  //广告栏上的图片
}
