package com.example.bean;


public class VideoBean{
    public int videoId;          // 视频Id
    public int chapterId; // 章节名称
    public String title;	// 视频名称
    public String secondTitle;	// 视频图标
    public String videoPath; 	// 视频播放地址

}
