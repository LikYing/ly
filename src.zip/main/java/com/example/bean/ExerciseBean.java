package com.example.bean;

public class ExerciseBean {
    public int id;//每章习题id
    public String title;//每章习题标题
    public String content;//每章习题的数目
    public int background;//每章习题的序号背景
    public int subjectId;//每道习题的id
    public  String subject;//每道习题的题干
    public String a;//每道习题的a选项
    public String b;//每道习题的b选项
    public String c;//每道习题的c选项
    public String d;//每道习题的d选项
    public int answer;//每道习题的正确答案
    /**
     * select为0表示选项是对的，1表示选项中a是错的，2表示选项中的b是错的，3表示选项中的c是错的，4表示选项中的d是错的
     */
    public int select;
}
