package com.example.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import com.example.activity.VideoPlayActivity;
import com.example.bean.VideoBean;
import com.example.myclass.R;

import java.util.List;

public class PlayHistoryAdapter extends BaseAdapter {
        private Context context;
        private List<VideoBean> vbl;
        public PlayHistoryAdapter(Context context) {
            this.context = context;
        }
        public void setData(List<VideoBean> vbl) {
            this.vbl = vbl;            //接收传递过来的视频集合数据
            notifyDataSetChanged();  //刷新界面数据
        }


    @Override
    public int getCount() {
        return vbl == null?0:vbl.size();
    }

    @Override
    public Object getItem(int i) {
        return vbl == null?0:vbl.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
            final ViewHolder vh;
            if(convertView == null){
                vh = new ViewHolder();
                convertView = LayoutInflater.from(context).inflate(R.layout.play_history_list_item,null);
                vh.tv_title = convertView.findViewById(R.id.tv_chapter_title);
                vh.tv_video_title = convertView.findViewById(R.id.tv_video_title );
                vh.iv_icon = convertView.findViewById(R.id.iv_video_icon);
                convertView.setTag(vh);
            }else {
                vh =(ViewHolder) convertView.getTag();
            }
            VideoBean bean = (VideoBean) getItem(position);
            if(bean != null){
                vh.tv_title.setText(bean.title);
                vh.tv_video_title.setText(bean.secondTitle);
                switch (bean.chapterId){
                    case 1:
                        vh.iv_icon.setImageResource(R.drawable.video_play_icon1);
                        break;
                    case 2:
                        vh.iv_icon.setImageResource(R.drawable.video_play_icon2);
                        break;
                    case 3:
                        vh.iv_icon.setImageResource(R.drawable.video_play_icon3);
                        break;
                    case 4:
                        vh.iv_icon.setImageResource(R.drawable.video_play_icon4);
                        break;
                    case 5:
                        vh.iv_icon.setImageResource(R.drawable.video_play_icon5);
                        break;
                    case 6:
                        vh.iv_icon.setImageResource(R.drawable.video_play_icon6);
                        break;
                    case 7:
                        vh.iv_icon.setImageResource(R.drawable.video_play_icon7);
                        break;
                    case 8:
                        vh.iv_icon.setImageResource(R.drawable.video_play_icon8);
                        break;
                    case 9:
                        vh.iv_icon.setImageResource(R.drawable.video_play_icon9);
                        break;
                    case 10:
                        vh.iv_icon.setImageResource(R.drawable.video_play_icon10);
                        break;
                }
            }
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(bean == null) return;
                    // 跳转到播放视频界面
                    Intent intent=new Intent(context, VideoPlayActivity.class);
                    intent.putExtra("videoPath", bean.videoPath);
                    context.startActivity(intent);
                }
            });
        return convertView;
    }

    class ViewHolder{
            TextView tv_title, tv_video_title;
            ImageView iv_icon;
        }
}
