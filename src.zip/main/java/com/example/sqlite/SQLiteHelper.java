package com.example.sqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class SQLiteHelper extends SQLiteOpenHelper {
    public  static final String DB_NAME = "bxg.db";
    public  static final int DB_VERSION = 1;
    public  static final String U_USERINFO = "userinfo";
    public  static final String U_VIDEO_PLAY_LIST = "videoplaylist";

    public SQLiteHelper(Context context) {
        super(context,DB_NAME,null,DB_VERSION);
    }

    public SQLiteHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    /*
        创建数据库
         */
    @Override
    public void onCreate(SQLiteDatabase db) {
        /**
     * 创建视频播放记录
     */
        db.execSQL("CREATE TABLE IF NOT EXISTS " +  U_USERINFO + "( "
                + "_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "userName VARCHAR, "//用户名
                + "nickName VARCHAR, "//昵称
                + "sex VARCHAR, "//性别
                + "signature VARCHAR"//签名
                +")");

        db.execSQL("CREATE TABLE  IF NOT EXISTS " + U_VIDEO_PLAY_LIST + "( "
                + "_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "userName VARCHAR, "    	//用户名
                + "chapterId INT, "       	//章节Id号
                + "videoId INT, "         	//视频Id号
                + "videoPath VARCHAR, "  	//视频地址
                + "title VARCHAR, "	//视频章节名称
                + "secondTitle VARCHAR " 	//视频名称
                + ")");

    }



    /*
    数据库升级
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + U_USERINFO);
        db.execSQL("DROP TABLE IF EXISTS " + U_VIDEO_PLAY_LIST);
        onCreate(db);
    }
}
